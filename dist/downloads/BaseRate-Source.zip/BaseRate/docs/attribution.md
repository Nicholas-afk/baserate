# Attribution, authorship and rights

BaseRate's application code, interface, educational copy, synthetic examples, training/audit code and submission materials were created with extensive AI assistance at the entrant's direction. Automated tests and AI-assisted code review are development evidence. No human learner study, educator endorsement, medical expertise or measured learning/health effect is claimed. The entrant must understand and explain the implementation under the competition's AI-assistance condition.

## Content and design sources

- [Hoffrage et al., 2015, Frontiers in Psychology](https://pmc.ncbi.nlm.nih.gov/articles/PMC4604268/): natural-frequency representations informed the population/counting approach. The paper does not evaluate BaseRate.
- [Gigerenzer, BMJ 2011, What are natural frequencies?](https://www.bmj.com/content/343/bmj.d6386): reference groups and interpretation of frequencies.
- [National Cancer Institute, Cancer Screening Overview](https://www.cancer.gov/about-cancer/screening/patient-screening-overview-pdq): benefits, harms and screening context, not validation of this fictional simulator.
- [Nielsen Norman Group, visual design principles](https://www.nngroup.com/articles/principles-visual-design/): hierarchy, contrast and grouping informed design decisions.
- [GOV.UK Design System, Details](https://design-system.service.gov.uk/components/details/): progressive disclosure informed advanced methods sections.
- Existing educational tools are compared, with their original links, in [research.md](research.md). The calculator and visual Bayes explanation are established ideas; the project does not claim to invent them.

These are linked references, not bundled papers or endorsements. Original prose summarizes concepts. No external font, stock-image library, icon package or third-party JavaScript is loaded. The interface uses Georgia and system font fallbacks, CSS patterns, native controls and an inline original letter favicon. Screenshots show the actual application.

## License and media

[MIT](../LICENSE) covers original application source, documentation and synthetic dataset. Linked sources retain their own rights. The competition demo includes the entrant's supplied narration over actual app states and a visual feature tour. Public distribution of that final demo is authorized for this project; the raw voice recording is excluded. The MIT source license does not grant rights to reuse the entrant's voice or impersonate them.

The 84-second demo was recorded before the latest coaching/denominator-feedback refinements. Its recording is preserved; the current application, model card and written materials are the authority for current behavior. No participant identity, biography or outcomes are invented.
